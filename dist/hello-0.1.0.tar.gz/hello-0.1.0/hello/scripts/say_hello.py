from colorama import Fore

def main():
    print(Fore.RED + 'hello')
    
if __name__ == '__main__':
    main()
